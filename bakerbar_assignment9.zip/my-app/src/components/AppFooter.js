import React from "react";

function AppFooter() {
    return (
        <footer className="App-footer">
            <p>2024 Baron Baker</p>
        </footer>
    );
};

export default AppFooter;